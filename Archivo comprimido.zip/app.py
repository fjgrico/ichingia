import streamlit as st
import random
import os
from openai import OpenAI

# Configuración Streamlit
st.set_page_config(page_title="IChingIA", layout="centered")
st.title("🔮 IChingIA")
st.markdown("Consulta el I Ching con interpretación basada en GPT-3.5 y textos originales")

# Cargar API key
client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])

def lanzar_moneda():
    return random.choice([6, 7, 8, 9])

def obtener_linea(valor):
    if valor == 6:
        return "⚪⚪⚪", "yin", True
    elif valor == 7:
        return "⚪ ⚪", "yin", False
    elif valor == 8:
        return "⚫ ⚫", "yang", False
    elif valor == 9:
        return "⚫⚫⚫", "yang", True

def calcular_hexagramas(tiradas):
    binario = ["1" if l in [8, 9] else "0" for l in tiradas]
    binario_mutado = ["1" if l in [7, 9] else "0" for l in tiradas]
    decimal = int("".join(reversed(binario)), 2) + 1
    decimal_mutado = int("".join(reversed(binario_mutado)), 2) + 1
    return decimal, decimal_mutado

def cargar_texto_hexagrama(numero):
    try:
        with open(f"hexagramas_txt/hexagrama_{numero}.txt", "r", encoding="utf-8") as f:
            return f.read()
    except:
        return "Texto no disponible para este hexagrama."

st.markdown("### 🧾 ¿Qué deseas consultar al I Ching?")
pregunta = st.text_input("Introduce tu consulta aquí:")

modo = st.radio("🎲 ¿Cómo deseas lanzar las monedas?", ["Tirada automática", "Tiradas individuales"])
tiradas = []
mostrar_resultado = False

if modo == "Tirada automática":
    if st.button("Lanzar 6 monedas"):
        tiradas = [lanzar_moneda() for _ in range(6)]
        mostrar_resultado = True
else:
    if "tiradas_individuales" not in st.session_state:
        st.session_state.tiradas_individuales = []
    if st.button("Lanzar moneda individual"):
        st.session_state.tiradas_individuales.append(lanzar_moneda())
    tiradas = st.session_state.tiradas_individuales
    st.markdown(f"Lanzamientos realizados: {len(tiradas)}/6")
    if len(tiradas) == 6:
        mostrar_resultado = True

if mostrar_resultado and len(tiradas) == 6:
    lineas = []
    lineas_mutantes = []
    visual = []

    for i, val in enumerate(tiradas):
        simbolo, tipo, muta = obtener_linea(val)
        visual.append(f"{6 - i}: {simbolo} {'(mutante)' if muta else ''}")
        if muta:
            lineas_mutantes.append(6 - i)
        lineas.append(tipo)

    st.markdown("### 🧬 Hexagrama lanzado")
    for l in visual:
        st.markdown(l)

    hex_num, hex_mutado = calcular_hexagramas(tiradas)
    nombre_original = cargar_texto_hexagrama(hex_num).splitlines()[0] if hex_num else ""
    nombre_mutado = cargar_texto_hexagrama(hex_mutado).splitlines()[0] if hex_mutado else ""

    st.markdown(f"🔷 Hexagrama obtenido: **{nombre_original}** (#{hex_num})")
    if lineas_mutantes:
        st.markdown(f"🌀 Líneas mutantes: {lineas_mutantes}")
        st.markdown(f"🌱 Hexagrama resultante por mutación: **{nombre_mutado}** (#{hex_mutado})")

    if pregunta:
        texto_original = cargar_texto_hexagrama(hex_num)
        texto_mutado = cargar_texto_hexagrama(hex_mutado) if lineas_mutantes else ""
        texto_extra = f"\nHexagrama mutado: #{hex_mutado} - {nombre_mutado}\n{texto_mutado}" if texto_mutado else ""

        prompt = f"""
Eres un sabio taoísta que interpreta el I Ching. Usa los textos originales para responder con profundidad y sensibilidad. 
Responde por áreas: espiritual, emocional, relaciones, trabajo y propósito de vida.

Pregunta del usuario: "{pregunta}"

Hexagrama base: #{hex_num} - {nombre_original}
Texto:
{texto_original}
{texto_extra}
"""

        with st.spinner("Consultando al I Ching..."):
            try:
                response = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "Eres un maestro taoísta que interpreta el I Ching desde la sabiduría milenaria."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.7,
                    max_tokens=2000
                )
                interpretacion = response.choices[0].message.content
                st.markdown("### ✨ Interpretación del I Ching")
                st.markdown(interpretacion)
            except Exception as e:
                st.error(f"Error al generar la interpretación: {str(e)}")
else:
    if modo == "Tiradas individuales" and len(tiradas) > 0:
        st.markdown("Cuando completes las 6 tiradas, se mostrará el resultado.")